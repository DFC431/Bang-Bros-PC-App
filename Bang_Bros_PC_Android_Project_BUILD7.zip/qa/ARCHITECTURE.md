# Architecture notes

BUILD 7 remains intentionally dependency-light: one Activity, programmatic Android views, SharedPreferences/JSON storage, Android PdfDocument, and AndroidX Core for FileProvider/window-inset support.

### Navigation model
`show(screen)` clears and repopulates the single content container. No screen is appended to another screen. The toolbar and bottom navigation remain outside the ScrollView.

### Performance choices
- One ScrollView per screen.
- No nested ScrollViews.
- `setSmoothScrollingEnabled(false)` avoids extra animation work while dragging long quotation forms.
- Bottom navigation is fixed, not part of the scroll content.
- Re-rendering is performed only when a screen is explicitly opened or a row changes.

### Data model
Products and quotations are persisted as JSON arrays in app-private SharedPreferences. This keeps the prototype offline-first and avoids external account requirements.

### Security/privacy
Purchase cost and calculated private profit are used internally and intentionally excluded from customer-facing PDF content. PDF sharing uses a `content://` URI via FileProvider instead of exposing a `file://` URI.
