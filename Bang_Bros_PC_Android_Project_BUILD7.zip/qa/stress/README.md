# Large fixture

`large_fixture.bin` is intentionally 37,000,000 bytes of non-compressible data. It is never copied into Android resources and is not included in the APK. Its purpose is to make the source ZIP >35 MB for upload/download/archive stress testing.
