# Bang Bros PC — BUILD 7 QA / Stress Package

This package is intentionally larger than a normal Android source archive. The `qa/stress/large_fixture.bin` file is a non-runtime test fixture used only to exercise upload/download/archive handling and repository workflows. It is **not packaged into the APK**.

## What BUILD 7 targets
- Dedicated dashboard navigation to quotation, builder, saved quotes and stock.
- Fixed top back/home controls and a fixed bottom navigation bar.
- System Back returns to Dashboard; Back on Dashboard exits the activity.
- Safe-area insets for status/navigation bars to reduce accidental taps.
- Centered content margins and consistent cards/buttons.
- Dark-on-light form controls for readability.
- Local quotation persistence using SharedPreferences + JSON.
- Product stock database with add/edit/delete.
- Stock picker can populate component price/cost/specification/status.
- Basic CPU socket and RAM generation compatibility checks.
- Private cost/profit calculations separated from customer PDF output.
- FileProvider-based PDF sharing for modern Android versions.
- Saved quotation open/duplicate/delete workflow.
- Smooth scrolling deliberately disabled to reduce jank on long forms.

## Manual QA checklist
1. Launch → Dashboard.
2. Tap every dashboard card and confirm it replaces the screen rather than appending below it.
3. Use top-left Back, top-right Home, bottom navigation and Android system Back.
4. Create a quotation with 10–20 component rows and scroll from top to bottom repeatedly.
5. Add a stock product, edit it, delete it, then pick it inside a component row.
6. Enter an AM5 CPU + B650 + DDR5 combination and confirm no obvious conflict warning.
7. Enter an AM5 CPU + B650 + DDR4 combination and confirm a RAM warning.
8. Enter selling and purchase prices and verify private profit.
9. Save, open, duplicate and delete quotations.
10. Generate/share a PDF and verify purchase cost/profit are not exposed to the customer.
11. Rotate is intentionally locked to portrait for predictable quotation layout.
12. Test on a small Android phone and a larger screen; verify the bottom navigation stays above the system navigation area.

## Large archive note
The large fixture is deliberately random/non-compressible so the ZIP remains >35 MB. This tests GitHub/phone upload, download and extraction handling without artificially bloating the APK or runtime memory.
