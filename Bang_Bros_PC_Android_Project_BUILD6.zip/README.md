# Bang Bros PC Android App — BUILD 6

Phone-friendly native Android quotation/business app.

BUILD 6 UI/navigation updates:
- Dedicated top navigation with Back, Home and Menu controls.
- Android system Back returns to Dashboard from any app screen.
- Extra horizontal/bottom safe spacing to reduce accidental taps near system UI.
- Improved light theme, contrast, rounded cyan action buttons and readable fields.
- Cleaner screen replacement and scrolling behavior.
- Preserves quotation, builder, stock, saved quote, PDF/share and compatibility features from BUILD 5.

Build with the included GitHub Actions workflow. Upload this ZIP to the same repository and update the workflow ZIP filename to BUILD6 if needed.
