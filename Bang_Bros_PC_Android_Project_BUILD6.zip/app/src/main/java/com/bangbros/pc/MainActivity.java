package com.bangbros.pc;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    String currentScreen="Dashboard";
    ScrollView scroller;
    SharedPreferences db;
    ArrayList<Item> items = new ArrayList<>();
    ArrayList<Product> products = new ArrayList<>();
    EditText customer, phone, email, address, quoteNo, date, validity, budget, discount, gst, delivery, service, notes;
    CheckBox gstOn;
    TextView total, remaining, profit, compatibility;
    Spinner mode;
    final int BLUE=Color.rgb(24,183,255), NAVY=Color.rgb(8,16,30), BG=Color.rgb(244,246,249), BORDER=Color.rgb(220,224,230), DARK=Color.rgb(45,50,58);
    final String[] cats={"CPU","Motherboard","GPU","RAM","SSD/NVMe","HDD","CPU Cooler","PSU","PC Case","Additional Fans","Wi-Fi/Bluetooth","Monitor","Keyboard","Mouse","UPS","Operating System","Other"};

    @Override public void onCreate(Bundle b){super.onCreate(b); db=getSharedPreferences("bangbros",0); seed(); show("Dashboard");}

    void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(8,8,8,8); bar.setBackgroundColor(NAVY);
        TextView back=t("‹",34,Color.WHITE); back.setGravity(Gravity.CENTER); back.setPadding(0,0,0,3);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(48,58); back.setVisibility(View.GONE); bar.addView(back,bp);
        TextView brand=t("BANG BROS PC",19,Color.WHITE); brand.setTypeface(null,Typeface.BOLD); brand.setGravity(Gravity.CENTER_VERTICAL); bar.addView(brand,new LinearLayout.LayoutParams(0,58,1));
        TextView home=t("⌂",25,Color.WHITE); home.setGravity(Gravity.CENTER); home.setContentDescription("Home"); bar.addView(home,new LinearLayout.LayoutParams(48,58));
        TextView menu=t("☰",25,Color.WHITE); menu.setGravity(Gravity.CENTER); menu.setContentDescription("Menu"); bar.addView(menu,new LinearLayout.LayoutParams(48,58));
        back.setOnClickListener(v->goBack()); home.setOnClickListener(v->show("Dashboard")); menu.setOnClickListener(v->showMenu());
        root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,12,12,72);
        scroller=new ScrollView(this); scroller.setFillViewport(true); scroller.setSmoothScrollingEnabled(true); scroller.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS); scroller.setVerticalScrollBarEnabled(true); scroller.addView(content,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroller,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        root.setTag(back);
    }
    TextView t(String s,int sp,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);v.setGravity(Gravity.CENTER_VERTICAL);v.setIncludeFontPadding(true);return v;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setGravity(Gravity.CENTER);b.setMinHeight(52);b.setMinimumHeight(52);b.setPadding(14,7,14,7);GradientDrawable g=new GradientDrawable();g.setColor(BLUE);g.setCornerRadius(14);b.setBackground(g);b.setStateListAnimator(null);return b;}
    Button outlineBtn(String s){Button b=btn(s);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setStroke(2,BLUE);g.setCornerRadius(14);b.setBackground(g);b.setTextColor(BLUE);return b;}
    EditText e(String hint){EditText x=new EditText(this);x.setHint(hint);x.setSingleLine(true);x.setTextColor(NAVY);x.setHintTextColor(Color.rgb(115,120,130));x.setTextSize(15);x.setPadding(14,7,14,7);x.setInputType(InputType.TYPE_CLASS_TEXT);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(11);g.setStroke(1,BORDER);x.setBackground(g);x.setMinimumHeight(54);return x;}
    void title(String s){TextView h=t(s,24,NAVY);h.setTypeface(null,Typeface.BOLD);h.setPadding(3,10,3,12);content.addView(h);}
    void section(String s){TextView h=t(s,18,NAVY);h.setTypeface(null,Typeface.BOLD);h.setPadding(3,16,3,8);content.addView(h);}
    void showMenu(){String[] a={"Dashboard","Create Quotation","PC Builder","Saved Quotations","Products / Stock","Customers","Settings"};new AlertDialog.Builder(this).setTitle("Bang Bros PC").setItems(a,(d,w)->show(a[w])).show();}
    boolean preserveItems=false;
    void show(String s){
        if(root==null)base();
        content.removeAllViews();
        currentScreen=s;
        TextView back=(TextView)root.getTag();
        if(back!=null)back.setVisibility(s.equals("Dashboard")?View.GONE:View.VISIBLE);
        if((s.equals("Create Quotation")||s.equals("PC Builder"))&&!preserveItems)items.clear();
        if(s.equals("Dashboard"))dashboard();else if(s.equals("Create Quotation"))quotation(false);else if(s.equals("PC Builder"))quotation(true);else if(s.equals("Saved Quotations"))saved();else if(s.equals("Products / Stock"))stock();else if(s.equals("Customers"))customers();else settings();
        preserveItems=false;
        if(scroller!=null)scroller.post(()->scroller.scrollTo(0,0));
    }
    void goBack(){
        if(currentScreen.equals("Dashboard")){finish();return;}
        show("Dashboard");
    }
    @Override public void onBackPressed(){if(!currentScreen.equals("Dashboard"))show("Dashboard");else super.onBackPressed();}

    void dashboard(){
        title("Dashboard");
        card("Create a customer quotation","Customer details → Components → Compatibility → Price → PDF",()->show("Create Quotation"));
        card("PC Builder","Build and cost a PC before creating the quotation",()->show("PC Builder"));
        card("Saved Quotations","Open, duplicate or delete previous quotes",()->show("Saved Quotations"));
        card("Products / Stock","Maintain products, purchase price, selling price and stock",()->show("Products / Stock"));
        TextView r=t("All data stays on this device.",13,DARK);r.setPadding(6,18,6,4);content.addView(r);
    }
    void card(String a,String b,final Runnable r){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(16,10,16,10);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(17);c.setBackground(g);TextView x=t(a,18,NAVY);x.setTypeface(null,Typeface.BOLD);c.addView(x,new LinearLayout.LayoutParams(-1,40));c.addView(t(b,13,DARK),new LinearLayout.LayoutParams(-1,40));Button q=btn("Open");q.setOnClickListener(v->r.run());c.setOnClickListener(v->r.run());c.addView(q,new LinearLayout.LayoutParams(-1,54));content.addView(c,new LinearLayout.LayoutParams(-1,168));Space sp=new Space(this);content.addView(sp,new LinearLayout.LayoutParams(1,9));}

    void quotation(boolean builderMode){
        title(builderMode?"PC Builder":"Create Quotation");
        customer=e("Customer Name");phone=e("Mobile Number");email=e("Email (optional)");address=e("Address (optional)");address.setSingleLine(false);address.setMinLines(2);address.setMinimumHeight(88);
        quoteNo=e("Quotation Number");date=e("Date (DD-MM-YYYY)");validity=e("Validity (e.g. 7 Days)");budget=e("Customer Budget ₹ (optional)");
        date.setText(new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date()));quoteNo.setText("BBPC-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.getDefault()).format(new Date()));validity.setText("7 Days");
        section("Customer Details");addFields(customer,phone,email,address,quoteNo,date,validity,budget);
        if(builderMode){TextView hint=t("Builder mode: create a compatible build first, then save it as a customer quotation.",13,DARK);hint.setPadding(4,8,4,8);content.addView(hint);}
        section("Pricing");
        mode=new Spinner(this);mode.setBackgroundColor(Color.WHITE);mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Manual Quotation Pricing","Stock / Business Pricing"}));content.addView(mode,new LinearLayout.LayoutParams(-1,52));
        discount=e("Discount ₹");gst=e("GST %");delivery=e("Delivery / Shipping ₹");service=e("Assembly / Service ₹");gstOn=new CheckBox(this);gstOn.setText("Apply GST");gstOn.setTextColor(NAVY);gstOn.setTextSize(15);gstOn.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
        addFields(discount,gst);content.addView(gstOn,new LinearLayout.LayoutParams(-1,48));addFields(delivery,service);
        section("Components");
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Button add=btn("+ Add Component");content.addView(add);add.setOnClickListener(v->addRow(list,null));
        compatibility=t("Compatibility: add CPU, motherboard and RAM to check.",14,DARK);compatibility.setPadding(8,12,8,12);content.addView(compatibility);
        section("Notes / Terms & Conditions");notes=e("Notes / Terms & Conditions");notes.setSingleLine(false);notes.setMinLines(4);notes.setMinimumHeight(120);notes.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);notes.setText("Prices are subject to market availability.\nWarranty is as per manufacturer terms.\nAssembly/testing included if applicable.\nComponent availability and pricing may vary.");content.addView(notes);
        Button stockNote=btn("Add Stock Availability Message");content.addView(stockNote);stockNote.setOnClickListener(v->notes.append("\nCertain components may be available from our existing stock and can therefore be offered at a slightly lower price. If components need to be sourced separately, final pricing may vary with market availability."));
        total=t("Grand Total: ₹0",22,BLUE);total.setTypeface(null,Typeface.BOLD);total.setPadding(4,14,4,4);content.addView(total);
        remaining=t("",14,NAVY);remaining.setPadding(4,3,4,3);content.addView(remaining);profit=t("Private Profit: ₹0",15,DARK);profit.setPadding(4,3,4,10);content.addView(profit);
        Button save=btn(builderMode?"Save as Quotation":"Save Quotation");Button pdf=btn("Generate PDF & Share");content.addView(save);content.addView(pdf);
        save.setOnClickListener(v->saveCurrent());pdf.setOnClickListener(v->{saveCurrent();makePdf();});
        for(EditText x:new EditText[]{discount,gst,delivery,service,budget})x.setOnFocusChangeListener((v,h)->{if(!h)refresh(list);});
        refresh(list);
    }
    void addFields(View...vs){for(View v:vs){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58);p.setMargins(0,4,0,4);content.addView(v,p);}}

    void addRow(LinearLayout list,Item old){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(10,9,10,9);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(14);g.setStroke(1,BORDER);r.setBackground(g);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,0,0,9);list.addView(r,rp);
        Spinner cat=new Spinner(this);cat.setBackgroundColor(Color.WHITE);cat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats));if(old!=null)for(int i=0;i<cats.length;i++)if(cats[i].equals(old.cat))cat.setSelection(i);r.addView(cat,new LinearLayout.LayoutParams(-1,50));
        EditText bm=e("Brand / Model"),spec=e("Specification"),qty=e("Qty"),price=e("Selling Unit Price ₹"),cost=e("Purchase Unit Cost ₹");
        qty.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);cost.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Spinner st=new Spinner(this);st.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"In Stock","Need to Source","Out of Stock"}));
        if(old!=null){bm.setText(old.name);spec.setText(old.spec);qty.setText(String.valueOf(old.qty));price.setText(String.valueOf(old.price));cost.setText(String.valueOf(old.cost));st.setSelection(old.status);}
        r.addView(bm);r.addView(spec);LinearLayout nums=new LinearLayout(this);nums.setOrientation(LinearLayout.HORIZONTAL);nums.addView(qty,new LinearLayout.LayoutParams(0,58,1));nums.addView(price,new LinearLayout.LayoutParams(0,58,2));r.addView(nums);r.addView(cost);r.addView(st,new LinearLayout.LayoutParams(-1,50));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);Button pick=outlineBtn("Pick from Stock");Button remove=btn("Remove");actions.addView(pick,new LinearLayout.LayoutParams(0,54,1));actions.addView(remove,new LinearLayout.LayoutParams(0,54,1));r.addView(actions);
        pick.setOnClickListener(v->pickProduct(bm,spec,price,cost,st,cat));remove.setOnClickListener(v->{list.removeView(r);refresh(list);});
        r.setTag(new RowRefs(cat,bm,spec,qty,price,cost,st));
        View.OnFocusChangeListener rf=(v,has)->{if(!has)refresh(list);};
        bm.setOnFocusChangeListener(rf);spec.setOnFocusChangeListener(rf);qty.setOnFocusChangeListener(rf);price.setOnFocusChangeListener(rf);cost.setOnFocusChangeListener(rf);
        cat.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){refresh(list);}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        st.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){refresh(list);}public void onNothingSelected(android.widget.AdapterView<?> p){}});
    }
    void pickProduct(EditText bm,EditText spec,EditText price,EditText cost,Spinner st,Spinner cat){loadProducts();if(products.isEmpty()){Toast.makeText(this,"No products in stock database yet",Toast.LENGTH_SHORT).show();return;}String[] a=new String[products.size()];for(int i=0;i<products.size();i++){Product p=products.get(i);a[i]=p.brand+" "+p.product+" • Sell ₹"+money(p.sell)+" • Stock "+p.stock;}new AlertDialog.Builder(this).setTitle("Select Stock Product").setItems(a,(d,w)->{Product p=products.get(w);bm.setText(p.brand+" "+p.product);spec.setText(p.spec);price.setText(String.valueOf(p.sell));cost.setText(String.valueOf(p.buy));st.setSelection(p.stock>0?0:(p.stock==0?1:2));for(int i=0;i<cats.length;i++)if(cats[i].equalsIgnoreCase(p.cat))cat.setSelection(i);Toast.makeText(this,"Product applied",Toast.LENGTH_SHORT).show();}).show();}

    void refresh(LinearLayout list){
        items.clear();double sub=0,costSum=0;
        for(int i=0;i<list.getChildCount();i++){View v=list.getChildAt(i);Object tag=v.getTag();if(!(tag instanceof RowRefs))continue;RowRefs q=(RowRefs)tag;int qty=(int)Math.max(1,num(q.qty));double price=num(q.price),cost=num(q.cost);Item it=new Item(q.cat.getSelectedItem().toString(),q.bm.getText().toString(),q.spec.getText().toString(),qty,price,cost,q.st.getSelectedItemPosition());items.add(it);sub+=qty*price;costSum+=qty*cost;}
        double dis=Math.min(sub,Math.max(0,num(discount)));double taxable=Math.max(0,sub-dis);double tax=gstOn!=null&&gstOn.isChecked()?taxable*num(gst)/100:0;double grand=taxable+tax+num(delivery)+num(service);if(total!=null)total.setText("Grand Total: ₹"+money(grand));if(profit!=null)profit.setText("Private Profit: ₹"+money(grand-costSum));if(remaining!=null&&budget!=null){double b=num(budget);remaining.setText(b>0?"Budget remaining: ₹"+money(b-grand):"");}checkCompatibility();}
    void checkCompatibility(){if(compatibility==null)return;String cpu="",mb="",ram="";for(Item x:items){if(x.cat.equals("CPU"))cpu+=(x.name+" "+x.spec+" ");if(x.cat.equals("Motherboard"))mb+=(x.name+" "+x.spec+" ");if(x.cat.equals("RAM"))ram+=(x.name+" "+x.spec+" ");}ArrayList<String> problems=new ArrayList<>();String c=cpu.toUpperCase(),m=mb.toUpperCase(),r=ram.toUpperCase();if(c.contains("AM4")&&m.contains("B650"))problems.add("CPU is AM4 but motherboard is B650/AM5.");if(c.contains("AM5")&&m.matches(".*\\b(B350|B450|B550|X370|X470|X570)\\b.*"))problems.add("CPU is AM5 but motherboard appears AM4.");if(m.contains("B650")&&r.contains("DDR4"))problems.add("B650 uses DDR5; DDR4 RAM is incompatible.");if((m.contains("B450")||m.contains("B550"))&&r.contains("DDR5"))problems.add("This motherboard family normally uses DDR4; DDR5 is incompatible.");if(problems.isEmpty()){compatibility.setText("Compatibility: ✓ No obvious socket/RAM conflict detected.");compatibility.setTextColor(Color.rgb(0,130,70));}else{compatibility.setText("Compatibility warning: " + join(problems));compatibility.setTextColor(Color.rgb(190,70,20));}}
    String join(ArrayList<String>a){StringBuilder s=new StringBuilder();for(String x:a){if(s.length()>0)s.append(" ");s.append(x);}return s.toString();}

    void saveCurrent(){if(customer==null){Toast.makeText(this,"Open a quotation first",Toast.LENGTH_SHORT).show();return;}try{JSONObject o=currentJson();JSONArray all=new JSONArray(db.getString("quotes","[]"));boolean replaced=false;for(int i=0;i<all.length();i++){if(all.getJSONObject(i).optString("quote").equals(o.optString("quote"))){all.put(i,o);replaced=true;break;}}if(!replaced)all.put(o);db.edit().putString("quotes",all.toString()).apply();Toast.makeText(this,"Quotation saved",Toast.LENGTH_SHORT).show();}catch(Exception ex){Toast.makeText(this,"Could not save quotation",Toast.LENGTH_SHORT).show();}}
    JSONObject currentJson()throws Exception{JSONObject o=new JSONObject();o.put("quote",quoteNo.getText().toString());o.put("date",date.getText().toString());o.put("customer",customer.getText().toString());o.put("phone",phone.getText().toString());o.put("email",email.getText().toString());o.put("address",address.getText().toString());o.put("validity",validity.getText().toString());o.put("budget",budget.getText().toString());o.put("discount",discount.getText().toString());o.put("gst",gst.getText().toString());o.put("gstOn",gstOn.isChecked());o.put("delivery",delivery.getText().toString());o.put("service",service.getText().toString());o.put("notes",notes.getText().toString());JSONArray a=new JSONArray();for(Item x:items)a.put(x.json());o.put("items",a);return o;}

    void saved(){title("Saved Quotations");try{JSONArray a=new JSONArray(db.getString("quotes","[]"));if(a.length()==0){content.addView(t("No saved quotations yet.",15,DARK));return;}for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,10,14,10);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(12);c.setBackground(bg);TextView h=t(o.optString("quote")+" • "+o.optString("customer"),16,NAVY);h.setTypeface(null,Typeface.BOLD);c.addView(h);c.addView(t(o.optString("date"),13,DARK));LinearLayout bs=new LinearLayout(this);Button open=btn("Open"),dup=btn("Duplicate"),del=btn("Delete");bs.addView(open,new LinearLayout.LayoutParams(0,54,1));bs.addView(dup,new LinearLayout.LayoutParams(0,54,1));bs.addView(del,new LinearLayout.LayoutParams(0,54,1));c.addView(bs);content.addView(c,new LinearLayout.LayoutParams(-1,-2));Space sp=new Space(this);content.addView(sp,new LinearLayout.LayoutParams(1,8));final int idx=i;open.setOnClickListener(v->loadQuote(o,false));dup.setOnClickListener(v->loadQuote(o,true));del.setOnClickListener(v->deleteQuote(idx));}}catch(Exception ignored){}}
    void deleteQuote(int idx){try{JSONArray a=new JSONArray(db.getString("quotes","[]"));a.remove(idx);db.edit().putString("quotes",a.toString()).apply();show("Saved Quotations");}catch(Exception ignored){}}
    void loadQuote(JSONObject o,boolean dup){try{items.clear();JSONArray a=o.getJSONArray("items");for(int i=0;i<a.length();i++)items.add(Item.from(a.getJSONObject(i)));preserveItems=true;show("Create Quotation");customer.setText(o.optString("customer"));phone.setText(o.optString("phone"));email.setText(o.optString("email"));address.setText(o.optString("address"));quoteNo.setText(dup?"BBPC-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.getDefault()).format(new Date()):o.optString("quote"));date.setText(dup?new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date()):o.optString("date"));validity.setText(o.optString("validity"));budget.setText(o.optString("budget"));discount.setText(o.optString("discount"));gst.setText(o.optString("gst"));gstOn.setChecked(o.optBoolean("gstOn"));delivery.setText(o.optString("delivery"));service.setText(o.optString("service"));notes.setText(o.optString("notes"));}catch(Exception ex){Toast.makeText(this,"Could not open quotation",Toast.LENGTH_SHORT).show();}}

    void stock(){title("Products / Stock");Button add=btn("+ Add Product");content.addView(add);add.setOnClickListener(v->productDialog(null));loadProducts();if(products.isEmpty()){content.addView(t("No products yet. Add your first product.",15,DARK));return;}for(int i=0;i<products.size();i++){Product p=products.get(i);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,10,14,10);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(12);c.setBackground(g);c.addView(t(p.brand+" "+p.product,17,NAVY));c.addView(t("Category: "+p.cat+"  •  Stock: "+p.stock,13,DARK));c.addView(t("Buy ₹"+money(p.buy)+"  •  Sell ₹"+money(p.sell),13,DARK));LinearLayout bs=new LinearLayout(this);Button ed=btn("Edit"),del=btn("Delete");bs.addView(ed,new LinearLayout.LayoutParams(0,54,1));bs.addView(del,new LinearLayout.LayoutParams(0,54,1));c.addView(bs);content.addView(c,new LinearLayout.LayoutParams(-1,-2));Space sp=new Space(this);content.addView(sp,new LinearLayout.LayoutParams(1,8));final int idx=i;ed.setOnClickListener(v->productDialog(products.get(idx)));del.setOnClickListener(v->deleteProduct(idx));}}
    void loadProducts(){products.clear();try{JSONArray a=new JSONArray(db.getString("products","[]"));for(int i=0;i<a.length();i++)products.add(Product.from(a.getJSONObject(i)));}catch(Exception ignored){}}
    void deleteProduct(int idx){new AlertDialog.Builder(this).setTitle("Delete product?").setMessage("Remove this product from stock database?").setPositiveButton("Delete",(d,w)->{loadProducts();if(idx>=0&&idx<products.size())products.remove(idx);JSONArray a=new JSONArray();try{for(Product p:products)a.put(p.json());db.edit().putString("products",a.toString()).apply();show("Products / Stock");}catch(Exception ignored){}}).setNegativeButton("Cancel",null).show();}
    void productDialog(Product old){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText b=e("Brand"),p=e("Product / Model"),cat=e("Category (CPU/Motherboard/RAM/etc.)"),spec=e("Specification"),buy=e("Purchase Price"),sell=e("Selling Price"),st=e("Stock Qty");for(EditText x:new EditText[]{b,p,cat,spec,buy,sell,st})l.addView(x);
        final String oldKey=old==null?"":old.brand+"\u0000"+old.product;
        if(old!=null){b.setText(old.brand);p.setText(old.product);cat.setText(old.cat);spec.setText(old.spec);buy.setText(String.valueOf(old.buy));sell.setText(String.valueOf(old.sell));st.setText(String.valueOf(old.stock));}
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(old==null?"Add Product":"Edit Product").setView(l).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{Product q=new Product(b.getText().toString().trim(),p.getText().toString().trim(),cat.getText().toString().trim(),spec.getText().toString().trim(),Double.parseDouble(buy.getText().toString().trim()),Double.parseDouble(sell.getText().toString().trim()),Integer.parseInt(st.getText().toString().trim()));loadProducts();JSONArray a=new JSONArray();boolean replaced=false;for(Product z:products){String key=z.brand+"\u0000"+z.product;if(old!=null&&key.equals(oldKey)&&!replaced){a.put(q.json());replaced=true;}else a.put(z.json());}if(old==null)a.put(q.json());db.edit().putString("products",a.toString()).apply();dialog.dismiss();show("Products / Stock");}catch(Exception ex){Toast.makeText(this,"Please check product fields",Toast.LENGTH_SHORT).show();}}));dialog.show();}

    void customers(){title("Customers");try{JSONArray a=new JSONArray(db.getString("quotes","[]"));HashSet<String> seen=new HashSet<>();for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);String n=o.optString("customer");if(n.length()>0&&seen.add(n)){LinearLayout c=new LinearLayout(this);c.setPadding(12,10,12,10);c.setOrientation(LinearLayout.VERTICAL);c.addView(t(n,16,NAVY));c.addView(t(o.optString("phone"),13,DARK));content.addView(c,new LinearLayout.LayoutParams(-1,-2));}}}catch(Exception ignored){}}
    void settings(){title("Settings");content.addView(t("Bang Bros PC\nLocal-first quotation app\nPrivate purchase cost and profit are never printed on customer PDF.\n\nAll quotation and stock data is stored on this device.",16,NAVY));Button clear=btn("Clear All Saved Quotations");content.addView(clear);clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Clear saved quotations?").setPositiveButton("Delete",(d,w)->{db.edit().remove("quotes").apply();show("Saved Quotations");}).setNegativeButton("Cancel",null).show());}

    void makePdf(){
        try{double sub=0,costSum=0;for(Item x:items){sub+=x.qty*x.price;costSum+=x.qty*x.cost;}double dis=Math.min(sub,num(discount)),tax=gstOn.isChecked()?Math.max(0,sub-dis)*num(gst)/100:0,grand=Math.max(0,sub-dis)+tax+num(delivery)+num(service);File f=new File(getExternalFilesDir(null),quoteNo.getText().toString()+".pdf");PdfDocument doc=new PdfDocument();int pageNo=1,y=0;PdfDocument.Page page=null;Canvas c=null;Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(Typeface.DEFAULT);for(int i=0;i<=items.size();i++){if(page==null){PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,pageNo++).create();page=doc.startPage(pi);c=page.getCanvas();c.drawColor(Color.rgb(250,251,253));p.setColor(NAVY);c.drawRect(0,0,595,112,p);p.setColor(BLUE);c.drawRect(0,108,595,112,p);p.setColor(Color.WHITE);p.setTextSize(23);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("BANG BROS PC",25,36,p);p.setTextSize(18);c.drawText("PC BUILD QUOTATION",330,36,p);p.setTextSize(9);p.setTypeface(Typeface.DEFAULT);c.drawText("GAMING | PERFORMANCE | YOURS",332,53,p);y=140;if(i==0){p.setColor(NAVY);p.setTextSize(10);c.drawText("Customer: "+customer.getText(),25,y,p);c.drawText("Date: "+date.getText(),25,y+18,p);c.drawText("Validity: "+validity.getText(),25,y+36,p);p.setTextSize(18);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("₹"+money(grand),445,y+22,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);c.drawText("ESTIMATED TOTAL",445,y+37,p);y+=75;p.setColor(NAVY);c.drawRect(20,y-16,575,y+8,p);p.setColor(Color.WHITE);p.setTextSize(8);c.drawText("NO.",27,y,p);c.drawText("COMPONENT",58,y,p);c.drawText("BRAND / MODEL",170,y,p);c.drawText("QTY",440,y,p);c.drawText("PRICE",485,y,p);y+=25;}}
            if(i<items.size()){Item x=items.get(i);if(y>765){doc.finishPage(page);page=null;i--;continue;}p.setColor((i%2==0)?Color.WHITE:Color.rgb(239,243,247));c.drawRect(20,y-13,575,y+30,p);p.setColor(NAVY);p.setTextSize(8);c.drawText(String.valueOf(i+1),27,y+3,p);c.drawText(x.cat,58,y+3,p);String nm=x.name.length()>27?x.name.substring(0,27):x.name;c.drawText(nm,170,y+3,p);String sp=x.spec.length()>32?x.spec.substring(0,32):x.spec;c.drawText(sp,170,y+16,p);c.drawText(String.valueOf(x.qty),444,y+3,p);c.drawText("₹"+money(x.qty*x.price),485,y+3,p);y+=44;}else{p.setColor(NAVY);c.drawRect(20,y,575,y+70,p);p.setColor(Color.WHITE);p.setTextSize(9);c.drawText("Subtotal",360,y+18,p);c.drawText("Discount",360,y+32,p);c.drawText("GST",360,y+46,p);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("GRAND TOTAL",360,y+61,p);p.setColor(BLUE);p.setTextSize(12);c.drawText("₹"+money(grand),480,y+61,p);p.setTypeface(Typeface.DEFAULT);p.setColor(DARK);p.setTextSize(7);String n=notes.getText().toString().replace("\n","  ");if(n.length()>145)n=n.substring(0,145);c.drawText("Notes: "+n,25,y+92,p);p.setColor(NAVY);c.drawRect(0,816,595,842,p);p.setColor(Color.WHITE);p.setTextSize(9);c.drawText("THANK YOU FOR CHOOSING US!",205,832,p);doc.finishPage(page);page=null;}}
            if(page!=null){doc.finishPage(page);page=null;}FileOutputStream out=new FileOutputStream(f);doc.writeTo(out);out.close();doc.close();Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/pdf");Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"Share quotation"));}catch(Exception ex){Toast.makeText(this,"PDF error: "+ex.getMessage(),Toast.LENGTH_LONG).show();}}

    double num(EditText e){if(e==null)return 0;try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    String money(double n){return String.format(Locale.US,"%,.0f",n);}
    void seed(){if(!db.contains("products"))db.edit().putString("products","[]").apply();}

    static class RowRefs{Spinner cat,st;EditText bm,spec,qty,price,cost;RowRefs(Spinner a,EditText b,EditText c,EditText d,EditText e,EditText f,Spinner g){cat=a;bm=b;spec=c;qty=d;price=e;cost=f;st=g;}}
    static class Product{String brand,product,cat,spec;double buy,sell;int stock;Product(String a,String b,String c,String d,double e,double f,int g){brand=a;product=b;cat=c;spec=d;buy=e;sell=f;stock=g;}JSONObject json()throws Exception{JSONObject o=new JSONObject();o.put("brand",brand);o.put("product",product);o.put("cat",cat);o.put("spec",spec);o.put("buy",buy);o.put("sell",sell);o.put("stock",stock);return o;}static Product from(JSONObject o){return new Product(o.optString("brand"),o.optString("product"),o.optString("cat"),o.optString("spec"),o.optDouble("buy"),o.optDouble("sell"),o.optInt("stock"));}}
    static class Item{String cat,name,spec;int qty,status;double price,cost;Item(String a,String b,String c,int d,double e,double f,int g){cat=a;name=b;spec=c;qty=d;price=e;cost=f;status=g;}JSONObject json()throws Exception{JSONObject o=new JSONObject();o.put("cat",cat);o.put("name",name);o.put("spec",spec);o.put("qty",qty);o.put("price",price);o.put("cost",cost);o.put("status",status);return o;}static Item from(JSONObject o){return new Item(o.optString("cat"),o.optString("name"),o.optString("spec"),o.optInt("qty",1),o.optDouble("price"),o.optDouble("cost"),o.optInt("status"));}}
}
