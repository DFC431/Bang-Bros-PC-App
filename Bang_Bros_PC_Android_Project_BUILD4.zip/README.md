# Bang Bros PC — Android Project BUILD 4

Fixes in BUILD 4:
- Dashboard cards now navigate to separate screens instead of appending screens below Dashboard.
- Saved Quotations, Products/Stock and loaded quotations no longer duplicate/append their UI.
- Reuses the same ScrollView/content container for smoother navigation and scrolling.
- Input fields now use dark readable text and visible hints on white backgrounds.
- Address and Notes support multiline input.
- Demo build reloads the quotation screen cleanly.
- Modern FileProvider PDF sharing retained.

Build through the included GitHub Actions workflow.
