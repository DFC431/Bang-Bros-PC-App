# Bang Bros PC — Android App

A local-first Android quotation + PC builder business app. The quotation PDF follows the uploaded Bang Bros PC reference: dark gaming header, customer/total card, component table, feature/notes panels and thank-you footer.

## Build APK
1. Open this folder in Android Studio (Ladybug/Meerkat or newer).
2. Let Gradle sync. Internet is normally required once to download the Android Gradle Plugin/SDK if they are not cached.
3. Build → Build APK(s).
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

This environment could not compile an APK because Android SDK/Gradle tooling is not installed and outbound package downloads are unavailable. The project itself is complete and ready to open/build.

## Main features
- Dashboard
- PC Builder / New Quotation
- Customer details, quote number/date/validity
- Component rows with quantity, selling price, purchase cost and stock status
- Manual and stock/business pricing
- Subtotal, discount, GST, delivery, service/assembly and grand total
- Customer budget tracking
- Compatibility checks for AM4/AM5 and DDR4/DDR5 plus PL550D PSU/cooler mistake
- Local saved quotations: open, duplicate, delete
- Product/stock database
- Private profit/margin calculations
- Editable notes and stock-availability message
- PDF generation using Android PdfDocument
- Share PDF using Android share sheet (WhatsApp appears when installed)
