# Bang Bros PC — Android Build 5

Feature-complete native Android quotation/PC builder project.

## Included
- Dashboard with separate screens for Create Quotation, PC Builder, Saved Quotations and Products/Stock
- Responsive readable input fields and Bang Bros blue buttons
- Customer details, pricing, GST, discount, delivery and service charges
- Component cards with stock status, purchase cost and selling price
- Stock product picker to fill component pricing/cost from local product database
- CPU/motherboard/RAM compatibility warnings for common AM4/AM5 and DDR4/DDR5 combinations
- Automatic grand total, budget remaining and private profit
- Save/open/duplicate/delete quotations without duplicate screen rendering
- Product add/edit/delete and stock quantity management
- PDF quotation generation and Android share sheet via FileProvider
- Local-first SharedPreferences storage
- Reduced scroll animation and one-screen-at-a-time rendering to avoid the previous lag/append issue

## GitHub phone build
Upload this ZIP to the same repository and ensure `.github/workflows/build-apk.yml` points to `Bang_Bros_PC_Android_Project_BUILD5.zip`. Then open GitHub Actions and run **Build Bang Bros PC APK**. Download the generated `Bang-Bros-PC-debug-apk` artifact.
