# Bang Bros PC Android App — BUILD 3

This build fixes the dashboard/action buttons by using explicit visible button styling and making dashboard cards themselves clickable. It also fixes PDF sharing on Android 7+ / modern Android using FileProvider.

Build with the included GitHub Actions workflow or Android Studio.
